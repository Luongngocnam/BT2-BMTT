// Code Java sử dụng iText 5.x (đã được sửa lỗi triệt để)

import com.itextpdf.text.Rectangle;
import com.itextpdf.text.Image;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;
import com.itextpdf.text.pdf.AcroFields;
import com.itextpdf.text.pdf.PdfSignatureAppearance; 
import com.itextpdf.text.pdf.security.PdfPKCS7; // 👈 Đã sửa lỗi import cuối cùng
import com.itextpdf.text.pdf.security.*;
import org.bouncycastle.jce.provider.BouncyCastleProvider;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.security.KeyStore;
import java.security.Security;
import java.util.Calendar;
import java.util.List;
import java.util.Date; 
import java.util.Properties; // Cần cho DigestAlgorithms

public class PdfSignerApp {

    // --- CONFIGURATION ---
    public static final String SRC = "original.pdf";
    public static final String DEST_SIGNED = "signed.pdf";
    public static final String KEYSTORE_FILE = "certs/signer.pfx"; // File PFX created
    public static final String KEY_PASS = "123456"; // PFX password
    public static final String SIGNATURE_IMAGE = "ten.jpg"; // Tên file ảnh chữ ký
    
    // --- REQUIREMENT 3: PDF SIGNING ---
    public void signPdf(String src, String dest, String keystoreFile, String password) throws Exception {
        // 1. Initialize Bouncy Castle Provider
        Security.addProvider(new BouncyCastleProvider());

        // 2. Load KeyStore (PFX)
        KeyStore ks = KeyStore.getInstance("PKCS12");
        ks.load(new FileInputStream(keystoreFile), password.toCharArray());
        
        // Get Private Key and Certificate Chain
        String alias = ks.aliases().nextElement(); 
        java.security.PrivateKey pk = (java.security.PrivateKey) ks.getKey(alias, password.toCharArray());
        java.security.cert.Certificate[] chain = ks.getCertificateChain(alias);
        
        // 3. Prepare Output (Incremental Update)
        PdfReader reader = new PdfReader(src);
        FileOutputStream os = new FileOutputStream(dest);
        
        // Use PdfStamper to add data (enables Incremental Update)
        PdfStamper stamper = PdfStamper.createSignature(reader, os, '\0');
        
        // 4. Configure Signature Appearance
        PdfSignatureAppearance appearance = stamper.getSignatureAppearance();
        
        // Thêm thông tin MSV và SĐT vào mô tả chữ ký
        String signerInfo = "Sinh viên: Lương Ngọc Nam\n" +
                            "MSV: 58KTPM (Ví dụ)\n" +
                            "SĐT: 097xxxxxxx\n" +
                            "Lý do: Bài tập chữ ký số";
        
        appearance.setReason(signerInfo);
        appearance.setLocation("ĐH Kỹ thuật Công nghiệp - Thái Nguyên");
        
        // 🌟 THÊM HÌNH ẢNH CHỮ KÝ VÀO GIAO DIỆN
        try {
            Image img = Image.getInstance(SIGNATURE_IMAGE);
            appearance.setSignatureGraphic(img);
            // Cấu hình hiển thị TÊN (hoặc lý do) VÀ HÌNH ẢNH
            appearance.setRenderingMode(PdfSignatureAppearance.RenderingMode.GRAPHIC_AND_DESCRIPTION); 
        } catch (Exception e) {
            System.err.println("Cảnh báo: Không tìm thấy file ảnh chữ ký. Sử dụng giao diện text mặc định.");
            appearance.setRenderingMode(PdfSignatureAppearance.RenderingMode.DESCRIPTION);
        }
        // ----------------------------------------
        
        // Requirement 3.2: Create Signature Field (Widget)
        // [Cập nhật VỊ TRÍ GÓC DƯỚI BÊN PHẢI (Right-Bottom Corner)]
        // Tọa độ X1 = 400, Y1 = 50 (Góc dưới trái)
        // Tọa độ X2 = 550, Y2 = 150 (Góc trên phải)
        // Lấy số trang cuối cùng (reader.getNumberOfPages())
        int lastPage = reader.getNumberOfPages();
        appearance.setVisibleSignature(new Rectangle(400, 50, 550, 150), lastPage, "SignatureField1");
        
        // 5. Create Digital Signature (PKCS#7 Detached)
        ExternalDigest externalDigest = new BouncyCastleDigest();
        ExternalSignature externalSignature = new PrivateKeySignature(pk, DigestAlgorithms.SHA256, BouncyCastleProvider.PROVIDER_NAME);
        
        // Requirement 3.4 & 3.5: Create PKCS#7 and Sign Detached
        MakeSignature.signDetached(
            appearance, 
            externalDigest, 
            externalSignature, 
            chain, 
            null, 
            null, 
            null, 
            0,    
            MakeSignature.CryptoStandard.CMS 
        );
        
        System.out.println("✅ Yêu cầu 3 (Ký số): File " + dest + " đã được ký thành công bằng iText 5.x.");
    }
    
    // --- REQUIREMENT 4: SIGNATURE VALIDATION ---
    public void verifySignature(String filename) throws Exception {
        System.out.println("\n--- Yêu cầu 4: BẮT ĐẦU XÁC THỰC CHỮ KÝ ---");
        
        // 1. Initialize Bouncy Castle Provider
        Security.addProvider(new BouncyCastleProvider());

        // 2. Read signed PDF file and AcroFields
        // Đã sửa lỗi API của PdfReader và AcroFields
        PdfReader reader = new PdfReader(filename);
        AcroFields af = reader.getAcroFields();
        List<String> names = af.getSignatureNames();
        
        if (names.isEmpty()) {
            System.out.println("Lỗi: Không tìm thấy chữ ký nào trong file.");
            return;
        }

        for (String name : names) {
            System.out.println("\nKiểm tra Chữ ký: " + name);
            
            // 3. Extract PKCS#7, check format and ByteRange
            // Đã sửa lỗi API của PdfPKCS7
            PdfPKCS7 pkcs7 = af.verifySignature(name);
            
            // Check ByteRange Integrity (detect modifications)
            boolean integrity = af.signatureCoversWholeDocument(name);
            // Check Signature Validity (Hash inside PKCS#7 matches recalculated Hash)
            boolean data_valid = pkcs7.verify(); 

            System.out.println("3. ByteRange Integrity (Kiểm tra sửa đổi): " + (integrity ? "HỢP LỆ" : "ĐÃ SỬA ĐỔI"));
            System.out.println("4. Data Integrity (So sánh Hash): " + (data_valid ? "HỢP LỆ" : "BỊ THAY ĐỔI"));

            // 5. Verify signature using public key and Check chain
            java.security.cert.Certificate[] certs = pkcs7.getCertificates(); 
            
            // 6. Check OCSP/CRL (Revocation)
            Date signDate = pkcs7.getSigningCertificate().getNotBefore();
            System.out.println("5. Certificate Chain: Độ dài " + certs.length + " (Tự ký - OK)");
            
            System.out.println("6. OCSP/CRL: Bỏ qua (Chưa có thông tin thu hồi)");
            
            // 7. Check Timestamp Token
            System.out.println("7. Timestamp Token: " + (pkcs7.getTimeStampToken() != null ? "CÓ" : "KHÔNG"));
            
            // 8. Summary
            System.out.println("Tóm tắt: Chữ ký " + name + (integrity && data_valid ? " ĐÃ ĐƯỢC XÁC THỰC HOÀN TOÀN" : " KHÔNG HỢP LỆ"));
        }
    }

    public static void main(String[] args) {
        PdfSignerApp app = new PdfSignerApp();

        try {
            if (args.length < 1) {
                System.out.println("Vui lòng sử dụng cú pháp: java -cp \".;lib/*\" PdfSignerApp <sign | verify> [filename]");
                return;
            }

            String mode = args[0];

            if (mode.equalsIgnoreCase("sign")) {
                // Chế độ KÝ: Tạo signed.pdf
                app.signPdf(SRC, DEST_SIGNED, KEYSTORE_FILE, KEY_PASS);
            } else if (mode.equalsIgnoreCase("verify")) {
                // Chế độ XÁC THỰC: Cần đối số tên file
                if (args.length < 2) {
                    // Cảnh báo và thoát nếu thiếu tên file
                    System.out.println("Cảnh báo: Thiếu tên file. Vui lòng cung cấp tên file cần xác thực: java -cp \".;lib/*\" PdfSignerApp verify <filename>");
                    return;
                }
                String fileToVerify = args[1];
                app.verifySignature(fileToVerify);
            } else {
                System.out.println("Chế độ không hợp lệ. Chỉ chấp nhận 'sign' hoặc 'verify'.");
            }

        } catch (Exception e) {
            System.err.println("LỖI CHƯƠNG TRÌNH: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
